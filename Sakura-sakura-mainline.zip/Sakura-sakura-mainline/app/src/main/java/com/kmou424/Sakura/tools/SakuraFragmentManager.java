package com.kmou424.Sakura.tools;

import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.kmou424.Sakura.R;
import com.kmou424.Sakura.fragment.SakuraStatusFragment;
import com.kmou424.Sakura.preference.fragment.SettingsPreferenceFragment;

public class SakuraFragmentManager {
    private static Fragment RequestFragment(int fragment_id){
        Fragment sakuraFragment = new SakuraStatusFragment();
        Fragment settingsPreferenceFragment = new SettingsPreferenceFragment();
        switch (fragment_id){
            case R.attr.sakura_fragment_status:
                return sakuraFragment;
            case R.attr.settings_preference_fragment:
                return  settingsPreferenceFragment;
        }
        return new Fragment();
    }

    public void LoadFragment(AppCompatActivity activity, int fragment_id, TextView title_text) {
        activity.getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, SakuraFragmentManager.RequestFragment(fragment_id)).commit();
        switch (fragment_id) {
            case R.attr.sakura_fragment_status:
                title_text.setText(R.string.nav_status);
                break;
            case R.attr.settings_preference_fragment:
                title_text.setText(R.string.nav_settings);
                break;
        }
    }
}
