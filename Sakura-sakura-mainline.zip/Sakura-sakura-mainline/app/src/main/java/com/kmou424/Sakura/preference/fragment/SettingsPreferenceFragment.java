package com.kmou424.Sakura.preference.fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.PreferenceManager;

import com.google.android.material.snackbar.Snackbar;
import com.kmou424.Sakura.R;
import com.mikepenz.iconics.IconicsColor;
import com.mikepenz.iconics.IconicsDrawable;
import com.mikepenz.iconics.IconicsSize;
import com.mikepenz.iconics.typeface.IIcon;
import com.mikepenz.iconics.typeface.library.googlematerial.GoogleMaterial;

import java.util.Objects;

public class SettingsPreferenceFragment extends PreferenceFragmentCompat {
    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.preference_settings, rootKey);
        final SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(Objects.requireNonNull(getContext()));
        PreferenceManager preferenceManager = getPreferenceManager();
            SetIcon("refresh_repo", GoogleMaterial.Icon.gmd_sync);
            SetIcon("super_user", GoogleMaterial.Icon.gmd_flash_on);
            AddRefreshRepoPreference(preferenceManager);
            AddSuperUserPreference(sharedPreferences, preferenceManager);
    }
    private void SetIcon(String key, IIcon icon){
        if (Objects.requireNonNull(getContext()).getSharedPreferences("theme_data", Context.MODE_PRIVATE).getBoolean("isDarkMode", false)){
            Objects.requireNonNull(getPreferenceManager().findPreference(key)).setIcon(new IconicsDrawable(Objects.requireNonNull(getContext())).icon(icon).color(IconicsColor.parse("#ffffff")).size(IconicsSize.dp(24)));
        } else {
            Objects.requireNonNull(getPreferenceManager().findPreference(key)).setIcon(new IconicsDrawable(Objects.requireNonNull(getContext())).icon(icon).color(IconicsColor.parse("#000000")).size(IconicsSize.dp(24)));
        }
    }
    private void AddRefreshRepoPreference(PreferenceManager preferenceManager){
        Objects.requireNonNull(preferenceManager.findPreference("refresh_repo")).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                final CoordinatorLayout snack_bar_container = Objects.requireNonNull(getActivity()).findViewById(R.id.root_layout);
                Snackbar.make(snack_bar_container,"example",5000)
                        .show();
                return false;
            }
        });
    }
    private void AddSuperUserPreference(final SharedPreferences sharedPreferences, PreferenceManager preferenceManager){
        final String super_user_name = "super_user";
        final Preference super_user_preference = preferenceManager.findPreference(super_user_name);
        final boolean super_user_value = sharedPreferences.getBoolean(super_user_name, false);
        if (Objects.requireNonNull(super_user_preference).isEnabled()){
            if (super_user_value){
                super_user_preference.setSummary(R.string.settings_super_user_checked);
            } else {
                super_user_preference.setSummary(R.string.settings_super_user_not_checked);
            }
            super_user_preference.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                @Override
                public boolean onPreferenceClick (Preference preference) {
                    if (sharedPreferences.getBoolean(super_user_name, false)){
                        preference.setSummary(R.string.settings_super_user_checked);
                        sharedPreferences.edit().putBoolean(super_user_name, true).apply();
                        return true;
                    } else {
                        preference.setSummary(R.string.settings_super_user_not_checked);
                        sharedPreferences.edit().putBoolean(super_user_name, false).apply();
                        return false;
                    }
                }
            });
        } else {
            super_user_preference.setSummary(R.string.settings_super_user_disabled);
            sharedPreferences.edit().putBoolean(super_user_name, false).apply();
        }
    }
}