package com.kmou424.Sakura.fragment;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.kmou424.Sakura.R;
import com.kmou424.Sakura.theme.ThemeUtils;

import java.util.Objects;

public class SakuraStatusFragment extends Fragment {

    private MaterialCardView core_status_card;
    private ImageView core_status_icon;
    private ProgressBar core_status_progressbar;
    private TextView core_status_title_text;
    private TextView core_status_subtitle_text;
    private TextView core_status_extra_title_text;
    private MaterialButton core_status_update_buuton;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.sakura_fragment_status, container, false);
    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initial();
        onLoading();
    }
    private void initial(){
        core_status_card = Objects.requireNonNull(getView()).findViewById(R.id.sakura_core_status_card);
        core_status_icon = Objects.requireNonNull(getView()).findViewById(R.id.sakura_core_status_icon);
        core_status_progressbar = Objects.requireNonNull(getView()).findViewById(R.id.sakura_core_status_progressbar);
        core_status_title_text = Objects.requireNonNull(getView()).findViewById(R.id.sakura_core_status_title_text);
        core_status_subtitle_text = Objects.requireNonNull(getView()).findViewById(R.id.sakura_core_status_subtitle_text);
        core_status_extra_title_text = Objects.requireNonNull(getView()).findViewById(R.id.sakura_core_status_extra_title_text);
        core_status_update_buuton = Objects.requireNonNull(getView()).findViewById(R.id.sakura_core_status_update_button);
    }
    private void onLoading(){
        core_status_icon.setVisibility(View.GONE);
        core_status_progressbar.setVisibility(View.VISIBLE);
        core_status_title_text.setText("Checking");
        core_status_subtitle_text.setText("Core Version: Checking");
        core_status_extra_title_text.setText("Latest Version: Checking");
        core_status_update_buuton.setVisibility(View.GONE);
    }
    private void onLoaded(){
        core_status_icon.setVisibility(View.VISIBLE);
        core_status_progressbar.setVisibility(View.GONE);
        core_status_title_text.setText("Core is installed");
        core_status_subtitle_text.setText("Core Version: 1.0.0");
        core_status_extra_title_text.setText("Latest Version: 1.1.0");
        core_status_update_buuton.setVisibility(View.VISIBLE);
    }
}
