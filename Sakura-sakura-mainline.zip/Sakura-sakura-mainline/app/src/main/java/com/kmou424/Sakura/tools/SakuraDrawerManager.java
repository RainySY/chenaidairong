package com.kmou424.Sakura.tools;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.kmou424.Sakura.R;
import com.mikepenz.iconics.typeface.library.googlematerial.GoogleMaterial;
import com.mikepenz.materialdrawer.AccountHeader;
import com.mikepenz.materialdrawer.AccountHeaderBuilder;
import com.mikepenz.materialdrawer.Drawer;
import com.mikepenz.materialdrawer.DrawerBuilder;
import com.mikepenz.materialdrawer.interfaces.OnCheckedChangeListener;
import com.mikepenz.materialdrawer.model.DividerDrawerItem;
import com.mikepenz.materialdrawer.model.PrimaryDrawerItem;
import com.mikepenz.materialdrawer.model.ProfileDrawerItem;
import com.mikepenz.materialdrawer.model.SwitchDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IDrawerItem;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

public class SakuraDrawerManager {
    public static void InitDrawer(final SharedPreferences theme_data,
                               final SwitchDrawerItem night_mode_switch,
                               final Context context,
                               final AppCompatActivity activity,
                               final Toolbar toolbar,
                               final TextView title_text){
        if (theme_data.getBoolean("isDarkMode", false)){
            night_mode_switch.setChecked(true);
        }
        final AccountHeaderBuilder header = new AccountHeaderBuilder().
                withActivity(activity)
                .addProfiles(new ProfileDrawerItem().withName("Kirki Sena").withEmail("dx2689282850@gmail.com").withIcon(R.drawable.header));
        night_mode_switch.setSelectable(false);
        AccountHeader header_build = header.build();

        final DrawerBuilder drawerBuilder = new DrawerBuilder().withActivity(activity).withAccountHeader(header_build);

        drawerBuilder.withToolbar(toolbar)
                .withActionBarDrawerToggleAnimated(true)
                .withSelectedItem(0)
                .addDrawerItems(new PrimaryDrawerItem().withIcon(GoogleMaterial.Icon.gmd_equalizer).withName(context.getString(R.string.nav_status)).withTag("STATUS"))
                .addDrawerItems(new DividerDrawerItem())
                .addDrawerItems(new PrimaryDrawerItem().withIcon(GoogleMaterial.Icon.gmd_home).withName("Home").withTag("DEFAULT"))
                .addDrawerItems(new PrimaryDrawerItem().withIcon(GoogleMaterial.Icon.gmd_settings).withName(context.getString(R.string.nav_settings)).withTag("SETTINGS"))
                .addDrawerItems(night_mode_switch.withIcon(GoogleMaterial.Icon.gmd_brightness_medium).withTag("DARK_MODE"));
        final Drawer result = drawerBuilder.build();

        night_mode_switch.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NotNull IDrawerItem<?> iDrawerItem, @NotNull CompoundButton compoundButton, boolean b) {
                if (b){
                    theme_data.edit().putBoolean("isDarkMode", true).apply();
                    header.withHeaderBackground(R.color.material_drawer_dark_background);
                    result.closeDrawer();
                    activity.recreate();
                } else {
                    theme_data.edit().putBoolean("isDarkMode", false).apply();
                    header.withHeaderBackground(R.color.material_drawer_background);
                    result.closeDrawer();
                    activity.recreate();
                }
            }
        });

        drawerBuilder.setMOnDrawerItemClickListener$materialdrawer(new Drawer.OnDrawerItemClickListener() {
            @Override
            public boolean onItemClick(@Nullable View view, int i, @NotNull IDrawerItem<?> iDrawerItem) {
                if (iDrawerItem == night_mode_switch){
                    if (night_mode_switch.isChecked()){
                        night_mode_switch.setChecked(false);
                    } else {
                        night_mode_switch.setChecked(true);
                    }
                }
                switch (Objects.requireNonNull(iDrawerItem.getTag()).toString()){
                    case "DEFAULT":
                        break;
                    case "STATUS":
                        new SakuraFragmentManager().LoadFragment(activity,R.attr.sakura_fragment_status,title_text);
                        break;
                    case "SETTINGS":
                        new SakuraFragmentManager().LoadFragment(activity,R.attr.settings_preference_fragment,title_text);
                        break;
                }
                return false;
            }
        });
    }
}