package com.kmou424.Sakura.theme;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;
import com.jaeger.library.StatusBarUtil;
import com.kmou424.Sakura.R;

public class ThemeUtils {
    private Context context;

    public int SAKURA_THEME_NORMAL = 0;
    //public final static int SAKURA_THEME_DARK = 1;
    public int SAKURA_THEME_BLUE = 2;

    private int DefTheme = R.style.AppTheme;

    public ThemeUtils(Context pcontext){
        this.context = pcontext;
    }

    public int ThemeRequest(int theme_id){
        switch (theme_id){
            case 0:
                break;
        }
        return this.DefTheme;
    }

    public Boolean isDarkMode(SharedPreferences theme_data){
        return theme_data.getBoolean("isDarkMode", false);
    }

    public void SakuraDesignLoader(MaterialCardView content_card_view){
        content_card_view.setBackgroundDrawable(this.context.getDrawable(R.drawable.sakura_content_container_card_bg));
    }

    public void Themer(int theme_id, SharedPreferences theme_data, AppCompatActivity activity){
        if (new ThemeUtils(this.context).isDarkMode(theme_data)){
            activity.setTheme(R.style.AppThemeDark);
            StatusBarUtil.setDarkMode(activity);
        } else {
            activity.setTheme(new ThemeUtils(this.context).ThemeRequest(theme_id));
            StatusBarUtil.setLightMode(activity);
        }
        StatusBarUtil.setColor(activity, R.attr.SakuraStatusBarBackgroundColor);
    }

}
