package com.kmou424.Sakura;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.card.MaterialCardView;
import com.kmou424.Sakura.theme.ThemeUtils;
import com.kmou424.Sakura.tools.SakuraDrawerManager;
import com.kmou424.Sakura.tools.SakuraFragmentManager;
import com.mikepenz.materialdrawer.model.SwitchDrawerItem;

public class SakuraActivity extends AppCompatActivity {

    //Const Value List
    private AppCompatActivity ACTIVITY = SakuraActivity.this;
    private String TAG = "SakuraActivity";

    //Object
    private Toolbar toolbar;
    private MaterialCardView content_card_view;
    private TextView title_text;

    private SwitchDrawerItem night_mode_switch;
    private ThemeUtils themeUtils;

    //Tools Object List
    private SharedPreferences app_data_shared_preference;
    private SharedPreferences theme_data;

    private void DataInitial (){
        theme_data = getSharedPreferences("theme_data", MODE_PRIVATE);
        Log.d(TAG, "Theme Data was loaded");
        app_data_shared_preference = getSharedPreferences("app_data", MODE_PRIVATE);
        Log.d(TAG, "App Data was loaded");
    }
    private void ObjectInitial (){
        toolbar = findViewById(R.id.toolbar);
        content_card_view = findViewById(R.id.contentCardView);
        title_text = findViewById(R.id.sakura_title_text);
        night_mode_switch = new SwitchDrawerItem().withChecked(false).withName(getString(R.string.nav_night_mode));
        Log.d(TAG, "Objects Initial Succeed");
    }
    private void SetupToolbar(){
        setSupportActionBar(toolbar);
        Log.d(TAG, "Toolbar was loaded");
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        themeUtils = new ThemeUtils(this);
        DataInitial();
        themeUtils.Themer(theme_data.getInt("theme", 0),theme_data,ACTIVITY);
        setContentView(R.layout.sakura_main);
        ObjectInitial();
        SetupToolbar();
        SakuraDrawerManager.InitDrawer(theme_data, night_mode_switch, this, ACTIVITY, toolbar,title_text);
        themeUtils.SakuraDesignLoader(content_card_view);
        new SakuraFragmentManager().LoadFragment(ACTIVITY,R.attr.sakura_fragment_status,title_text);
    }

    private void applyTheme(int theme){
        theme_data.edit().putInt("theme", theme).apply();
        recreate();
    }
    private void getPermissions (){

    }
}